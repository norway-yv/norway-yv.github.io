# kode24-calculator
A calculator of expected wage for developers in Norway.
To run the code, download the entire thing and save it in the same directory. Then, run frontend.py.
REMEMBER: THIS IS NOT FINISHED YET!